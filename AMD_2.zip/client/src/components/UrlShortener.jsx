import React, { useState } from 'react';
import axios from 'axios';

function UrlShortener() {
    const [originalUrl, setOriginalUrl] = useState('');
    const [shortUrl, setShortUrl] = useState('');
    const [shortenedUrls, setShortenedUrls] = useState([]);
    const [error, setError] = useState('');

    const handleShorten = async () => {
        try {
            const response = await axios.post('https://localhost:8888/url', { originalUrl });
            setShortUrl(`https://localhost:8888/${response.data.shortUrl}`);
            setError('');
        } catch (error) {
            if (error.response && error.response.status === 409) {
                setError(error.response.data.message);
            } else {
                console.error('Error shortening URL:', error);
                setError('Error shortening URL');
            }
        }
    };

    const handleListAll = async () => {
        try {
            const response = await axios.get('https://localhost:8888/urls');
            setShortenedUrls(response.data);
            setError('');
        } catch (error) {
            console.error('Error fetching shortened URLs:', error);
            setError('Error fetching shortened URLs');
        }
    };

    return (
        <div className="container">
            <h1>URL Shortener</h1>
            <div className="input-group">
                <input
                    type="text"
                    placeholder="Enter URL"
                    value={originalUrl}
                    onChange={(e) => setOriginalUrl(e.target.value)}
                />
                <button onClick={handleShorten}>Shorten</button>
            </div>
            {shortUrl && (
                <div className="shortened-url">
                    <h2>Shortened URL:</h2>
                    <a href={shortUrl} target="_blank" rel="noopener noreferrer" className="link">
                        {shortUrl}
                    </a>
                </div>
            )}
            <button onClick={handleListAll}>List All Shortened URLs</button>
            {shortenedUrls.length > 0 && (
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Short URL</th>
                                <th>Original URL</th>
                            </tr>
                        </thead>
                        <tbody>
                            {shortenedUrls.map((url, index) => (
                                <tr key={index}>
                                    <td>
                                        <a href={url.originalUrl} target="_blank" rel="noopener noreferrer" className="link">
                                            https://localhost:8888/{url.shortUrl}
                                        </a>
                                    </td>
                                    <td>{url.originalUrl}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
            {error && <p className="error-message">{error}</p>}
        </div>
    );
}

export default UrlShortener;
