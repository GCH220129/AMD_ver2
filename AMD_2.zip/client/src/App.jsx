import React from 'react';
import ShortenUrl from './components/UrlShortener';
import './App.css';

const App = () => {
    return (
        <div className="App">
            <ShortenUrl />
        </div>
    );
};

export default App;